---
agent: speckit.git.validate
---
